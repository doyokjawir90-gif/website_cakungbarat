(() => {
  "use strict";
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const today = new Date();
  $("#todayLabel").textContent = today.toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
  $("#yearLabel").textContent = today.getFullYear();

  // Musik tidak autoplay: hanya mulai setelah pengunjung menekan tombol.
  const music = $("#backgroundMusic");
  const musicToggle = $("#musicToggle");
  const musicToggleText = $(".music-toggle-text", musicToggle);
  if (music && musicToggle) {
    music.volume = 0.35;
    const updateMusicButton = playing => {
      musicToggle.classList.toggle("is-playing", playing);
      musicToggle.setAttribute("aria-pressed", String(playing));
      musicToggle.setAttribute("aria-label", playing ? "Jeda musik instrumental Indonesia Raya" : "Putar musik instrumental Indonesia Raya");
      musicToggleText.textContent = playing ? "Jeda Musik" : "Putar Musik";
    };
    musicToggle.addEventListener("click", async () => {
      try {
        if (music.paused) {
          await music.play();
          updateMusicButton(true);
        } else {
          music.pause();
          updateMusicButton(false);
        }
      } catch (err) {
        updateMusicButton(false);
        toast("Musik belum dapat diputar. Periksa koneksi internet.");
      }
    });
    music.addEventListener("pause", () => updateMusicButton(false));
    music.addEventListener("play", () => updateMusicButton(true));
  }


  // Fitur aksesibilitas: mode suara dan pengaturan ukuran teks.
  const accessibilityToggle = $("#accessibilityToggle");
  const accessibilityPanel = $("#accessibilityPanel");
  const accessibilityClose = $("#accessibilityClose");
  const voiceModeToggle = $("#voiceModeToggle");
  let voiceActive = false;
  let textScale = 1;
  const setAccessibilityPanel = open => {
    accessibilityPanel.hidden = !open;
    accessibilityToggle.setAttribute("aria-expanded", String(open));
  };
  accessibilityToggle?.addEventListener("click", () => {
    setAccessibilityPanel(accessibilityPanel.hidden);
  });
  accessibilityClose?.addEventListener("click", () => setAccessibilityPanel(false));

  const updateTextScale = () => {
    document.documentElement.style.setProperty("--accessibility-text-scale", String(textScale));
    document.body.classList.toggle("accessibility-text-scaled", textScale !== 1);
  };
  $("#textIncrease")?.addEventListener("click", () => {
    textScale = Math.min(1.5, Math.round((textScale + 0.1) * 10) / 10);
    updateTextScale();
  });
  $("#textDecrease")?.addEventListener("click", () => {
    textScale = Math.max(0.8, Math.round((textScale - 0.1) * 10) / 10);
    updateTextScale();
  });
  $("#textReset")?.addEventListener("click", () => {
    textScale = 1;
    updateTextScale();
  });

  const stopVoiceMode = () => {
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    voiceActive = false;
    voiceModeToggle?.setAttribute("aria-pressed", "false");
    if (voiceModeToggle) voiceModeToggle.querySelector("strong").textContent = "Mode Suara";
  };
  voiceModeToggle?.addEventListener("click", () => {
    if (voiceActive) {
      stopVoiceMode();
      return;
    }
    if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) {
      toast("Mode suara tidak didukung browser ini.");
      return;
    }
    const mainContent = $("#publicView") || document.body;
    const textToRead = (mainContent.innerText || mainContent.textContent || "").replace(/\\s+/g, " ").trim();
    if (!textToRead) {
      toast("Tidak ada teks yang dapat dibacakan.");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(textToRead);
    utterance.lang = "id-ID";
    utterance.rate = 0.95;
    utterance.onend = stopVoiceMode;
    utterance.onerror = stopVoiceMode;
    voiceActive = true;
    voiceModeToggle.setAttribute("aria-pressed", "true");
    voiceModeToggle.querySelector("strong").textContent = "Hentikan Suara";
    window.speechSynthesis.speak(utterance);
  });


  const DEFAULT_MUSIC = "https://ncltr.info/fifco-assets/anthems/idn.mp3";
  let csrf = "", isAdmin = false;
  let news = [], complaints = [], services = [], settings = {}, progress = {active:[], completed:[]};

  // ---- Lapisan API: semua data berasal dari server ----
  async function api(path, {method="GET", body, form} = {}) {
    const opts = {method, headers:{}, credentials:"same-origin"};
    if (method !== "GET" && csrf) opts.headers["X-CSRF-Token"] = csrf;
    if (form) opts.body = form;
    else if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
    let res;
    try { res = await fetch("/api" + path, opts); }
    catch { throw new Error("Tidak dapat terhubung ke server. Periksa koneksi internet Anda."); }
    let data = null;
    try { data = await res.json(); } catch {}
    if (!res.ok) {
      const err = new Error((data && data.error) || "Terjadi kesalahan pada server.");
      err.status = res.status;
      if (res.status === 401 && isAdmin) sessionExpired();
      throw err;
    }
    return data;
  }
  async function loadPublic() {
    const d = await api("/public");
    services = d.services; settings = d.settings; progress = d.progress;
    if (!isAdmin) news = d.news;
  }
  async function loadAdmin() {
    const d = await api("/admin/data");
    news = d.news; complaints = d.complaints; services = d.services; settings = d.settings;
  }
  function currentProgress() {
    if (!isAdmin) return progress;
    const pick = s => complaints.filter(c => c.status === s).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,6)
      .map(c => ({id:c.id, category:c.category, date:c.date, status:c.status}));
    return {active: pick("Diproses"), completed: pick("Selesai")};
  }
  function renderPublicAll() { renderPublicNews(); renderPublicComplaints(); renderPublicServices(); renderContact(); applyHomeText(); applyMusic(); }
  async function refreshAdmin() { await loadAdmin(); renderPublicAll(); renderAdmin(); }

  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const formatDate = d => { if(!d) return "—"; const dt=new Date(d+"T00:00:00"); return Number.isNaN(dt.getTime()) ? esc(d) : dt.toLocaleDateString("id-ID",{day:"numeric",month:"short",year:"numeric"}); };
  const categoryClass = c => ({Pengumuman:"",Kegiatan:"theme-1",Layanan:"theme-2","Informasi Wilayah":"theme-3"}[c] || "");
  const toast = msg => { const el=$("#toast"); el.textContent=msg; el.classList.add("show"); clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),3500); };
  const showModal = id => { $("#"+id).classList.remove("hidden"); document.body.style.overflow="hidden"; };
  const hideModal = id => { $("#"+id).classList.add("hidden"); if(!$$(".modal-backdrop:not(.hidden)").length) document.body.style.overflow=""; };
  $$("[data-close]").forEach(b=>b.addEventListener("click",()=>hideModal(b.dataset.close)));
  $$(".modal-backdrop").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)hideModal(m.id)}));
  document.addEventListener("keydown",e=>{if(e.key==="Escape")$$(".modal-backdrop:not(.hidden)").forEach(m=>hideModal(m.id));});
  const mediaTag = (n, {card=false, slide=false} = {}) => {
    if (!n.mediaUrl) return "";
    if (n.mediaType === "video") return slide ? `<video src="${esc(n.mediaUrl)}" muted loop autoplay playsinline></video>` : `<video src="${esc(n.mediaUrl)}" muted playsinline controls preload="metadata"></video>`;
    return `<img src="${esc(n.mediaUrl)}" alt="${esc(n.title)}" loading="lazy">`;
  };

  function applyMusic() {
    if (!music) return;
    const wanted = settings.musicUrl || DEFAULT_MUSIC;
    const current = music.getAttribute("data-src") || "";
    if (current === wanted) return;
    const wasPlaying = !music.paused;
    music.setAttribute("data-src", wanted);
    music.innerHTML = "";
    music.src = wanted;
    music.load();
    if (wasPlaying) music.play().catch(()=>{});
  }

  function renderPublicComplaints(){
    const activeHost=$("#publicComplaintProgress");
    const completedHost=$("#completedComplaintProgress");
    if(!activeHost || !completedHost)return;
    const {active, completed} = currentProgress();
    activeHost.innerHTML=active.map(c=>`<article class="public-progress-card"><div class="public-progress-top"><span class="progress-ticket">${esc(c.id)}</span><span class="status-pill diproses">Sedang Dikerjakan</span></div><h3>${esc(c.category)}</h3><p>Pengaduan kategori ${esc(c.category.toLowerCase())} sedang ditangani oleh petugas kelurahan.</p><div class="progress-track" role="img" aria-label="Status pengaduan sedang dikerjakan"><span></span></div><div class="public-progress-meta"><span>✓ Diterima</span><span class="current-step">● Dalam penanganan</span><span>○ Selesai</span></div><small class="progress-date">Status diperbarui oleh petugas · ${formatDate(c.date)}</small></article>`).join("")||'<div class="progress-empty"><span>◷</span><strong>Belum ada pekerjaan yang sedang diproses</strong><p>Pengaduan akan tampil di sini setelah petugas mengubah statusnya menjadi “Diproses”.</p></div>';
    completedHost.innerHTML=completed.map(c=>`<article class="public-progress-card completed-progress-card"><div class="public-progress-top"><span class="progress-ticket">${esc(c.id)}</span><span class="status-pill selesai">Selesai</span></div><h3>${esc(c.category)}</h3><p>Pengaduan kategori ${esc(c.category.toLowerCase())} telah selesai ditangani.</p><div class="progress-track completed-track" role="img" aria-label="Pengaduan selesai ditangani"><span></span></div><div class="public-progress-meta"><span>✓ Diterima</span><span>✓ Ditangani</span><span class="completed-step">✓ Selesai</span></div><small class="progress-date">Status diperbarui oleh petugas · ${formatDate(c.date)}</small></article>`).join("")||'<div class="progress-empty completed-empty"><span>✓</span><strong>Belum ada pengaduan yang selesai</strong><p>Pengaduan yang statusnya diubah menjadi “Selesai” akan ditampilkan di bagian ini.</p></div>';
  }

  function renderPublicNews(){
    const q=($("#newsSearch").value||"").trim().toLowerCase(), cat=$("#newsCategory").value;
    const rows=news.filter(n=>n.published && (cat==="Semua"||n.category===cat) && (n.title+" "+n.excerpt+" "+n.body).toLowerCase().includes(q)).sort((a,b)=>b.date.localeCompare(a.date));
    $("#newsGrid").innerHTML=rows.map(n=>`<article class="news-card"><div class="news-visual ${categoryClass(n.category)}">${mediaTag(n)||`<span class="news-emoji">${esc(n.emoji||"📌")}</span>`}</div><div class="news-card-body"><div class="news-meta"><span class="category-pill">${esc(n.category)}</span><span>•</span><span>${formatDate(n.date)}</span></div><h3>${esc(n.title)}</h3><p>${esc(n.excerpt)}</p><button class="inline-link" data-read-news="${esc(n.id)}">Baca selengkapnya <span>→</span></button></div></article>`).join("");
    $("#newsEmpty").classList.toggle("hidden",rows.length!==0);
    renderLatestSlider();
  }
  let latestSlideIndex=0, latestSlideTimer=null;
  function latestRows(){return news.filter(n=>n.published && n.category==="Pengumuman").sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);}
  function renderLatestSlider(){
    const host=$("#latestNewsSlider");if(!host)return;
    const rows=latestRows();
    if(latestSlideTimer){clearInterval(latestSlideTimer);latestSlideTimer=null;}
    if(!rows.length){host.innerHTML='<div class="latest-slide active"><div class="latest-slide-copy"><h3>Belum ada pengumuman terkini</h3><p>Pengumuman yang sudah dipublikasikan oleh petugas akan ditampilkan di sini.</p></div></div>';$("#latestSliderDots").innerHTML="";return;}
    latestSlideIndex=Math.min(latestSlideIndex,rows.length-1);
    host.innerHTML=rows.map((n,i)=>`<article class="latest-slide ${i===latestSlideIndex?'active':''}" data-slide="${i}"><div class="latest-slide-copy"><span class="category-pill">${esc(n.category)}</span><small>${formatDate(n.date)}</small><h3>${esc(n.title)}</h3><p>${esc(n.excerpt)}</p><button class="btn btn-white" type="button" data-read-news="${esc(n.id)}">Baca berita <span>→</span></button></div><div class="latest-slide-media">${mediaTag(n,{slide:true})||`<span>${esc(n.emoji||'📰')}</span>`}</div></article>`).join("");
    $("#latestSliderDots").innerHTML=rows.map((_,i)=>`<button type="button" class="${i===latestSlideIndex?'active':''}" data-slide-to="${i}" aria-label="Tampilkan berita ${i+1}"></button>`).join("");
    if(rows.length>1)latestSlideTimer=setInterval(()=>{latestSlideIndex=(latestSlideIndex+1)%rows.length;renderLatestSlider();},5500);
  }
  function moveLatest(delta){const count=latestRows().length;if(!count)return;latestSlideIndex=(latestSlideIndex+delta+count)%count;renderLatestSlider();}
  $("#latestPrev")?.addEventListener("click",()=>moveLatest(-1));$("#latestNext")?.addEventListener("click",()=>moveLatest(1));
  $("#latestSliderDots")?.addEventListener("click",e=>{const b=e.target.closest("[data-slide-to]");if(b){latestSlideIndex=Number(b.dataset.slideTo);renderLatestSlider();}});
  $("#latestNewsSlider")?.addEventListener("click",e=>{const b=e.target.closest("[data-read-news]");if(b)openNewsDetail(b.dataset.readNews);});
  function openNewsDetail(id){
    const n=news.find(x=>x.id===id);if(!n)return;
    $("#detailKicker").textContent=n.category.toUpperCase()+" · "+formatDate(n.date);
    $("#detailTitle").textContent=n.title;
    const body=$("#detailBody");body.textContent=n.body||n.excerpt;
    if(n.mediaUrl){const el=document.createElement(n.mediaType==="video"?"video":"img");el.src=n.mediaUrl;if(n.mediaType==="video"){el.controls=true;el.playsInline=true;}else el.alt=n.title;el.className="detail-media";body.prepend(el);}
    showModal("detailModal");
  }
  $("#newsGrid").addEventListener("click",e=>{const b=e.target.closest("[data-read-news]");if(b)openNewsDetail(b.dataset.readNews);});
  $("#newsSearch").addEventListener("input",renderPublicNews);$("#newsCategory").addEventListener("change",renderPublicNews);
  $("#showAllNews").addEventListener("click",()=>{$("#newsSearch").value="";$("#newsCategory").value="Semua";renderPublicNews();});

  const serviceContainer=$(".service-cards");
  const serviceTemplate=$(".service-card",serviceContainer).cloneNode(true);
  function renderPublicServices(){
    serviceContainer.innerHTML="";
    services.forEach(service=>{
      const card=serviceTemplate.cloneNode(true);
      card.querySelector("h3").textContent=service.name;
      card.querySelector("p").textContent=service.summary;
      const btn=card.querySelector(".service-detail");
      btn.dataset.serviceId=service.id;
      btn.addEventListener("click",()=>{$("#detailKicker").textContent="PANDUAN LAYANAN";$("#detailTitle").textContent=service.name;$("#detailBody").textContent=service.body;showModal("detailModal");});
      serviceContainer.appendChild(card);
    });
  }
  $("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
  $$(".nav-link").forEach(a=>a.addEventListener("click",()=>{$$(".nav-link").forEach(x=>x.classList.remove("active"));a.classList.add("active");$("#mainNav").classList.remove("open");}));

  $("#complaintForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const btn=$("button[type=submit]",e.target);btn.disabled=true;
    try{
      const r=await api("/complaints",{method:"POST",body:{name:$("#complaintName").value,contact:$("#complaintContact").value,category:$("#complaintTopic").value,message:$("#complaintMessage").value,website:$("#complaintWebsite").value}});
      e.target.reset();toast("Pengaduan berhasil dikirim. Nomor tiket Anda: "+r.ticket+" (simpan nomor ini).");
    }catch(err){toast(err.message);}
    finally{btn.disabled=false;}
  });

  // ---- Sesi admin ----
  function setAdminIdentity(name){const n=name||"Administrator";$("#sidebarName").textContent=n;const ini=n.charAt(0).toUpperCase();$("#sidebarAvatar").textContent=ini;$("#topAvatar").textContent=ini;}
  function switchView(admin){
    $("#publicView").classList.toggle("hidden",admin);$("#adminView").classList.toggle("hidden",!admin);$("#footer").classList.toggle("hidden",admin);
    window.scrollTo({top:0,behavior:"smooth"});
    if(admin){renderAdmin();} else {window.location.hash="";renderPublicAll();}
  }
  async function enterAdmin(){isAdmin=true;await loadAdmin();switchView(true);switchPanel("overview");}
  async function leaveAdmin(){isAdmin=false;csrf="";try{await loadPublic();}catch{}switchView(false);}
  function sessionExpired(){isAdmin=false;csrf="";hideModal("newsModal");hideModal("serviceModal");loadPublic().catch(()=>{}).finally(()=>switchView(false));toast("Sesi berakhir. Silakan masuk kembali.");}
  $("#adminOpenBtn").addEventListener("click",async()=>{
    if(csrf){try{await enterAdmin();return;}catch{}}
    showModal("loginModal");
  });
  $("#loginForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const errEl=$("#loginError"),btn=$("button[type=submit]",e.target);btn.disabled=true;
    try{
      const r=await api("/login",{method:"POST",body:{username:$("#adminUsername").value.trim(),password:$("#adminPassword").value}});
      csrf=r.csrf;setAdminIdentity(r.username);hideModal("loginModal");errEl.classList.add("hidden");$("#loginForm").reset();
      await enterAdmin();toast("Berhasil masuk ke dashboard.");
    }catch(err){errEl.textContent=err.message;errEl.classList.remove("hidden");}
    finally{btn.disabled=false;}
  });
  $("#saveAdminAccount").addEventListener("click",async()=>{
    const current=$("#currentAdminPassword").value;
    const username=$("#newAdminUsername").value.trim();
    const password=$("#newAdminPassword").value;
    const confirmPw=$("#confirmAdminPassword").value;
    const status=$("#adminAccountStatus");
    const say=message=>{status.textContent=message;};
    if(!current){say("Masukkan password saat ini terlebih dahulu.");return;}
    if(!username&&!password){say("Masukkan username baru atau password baru terlebih dahulu.");return;}
    if(username&&username.length<3){say("Username minimal 3 karakter.");return;}
    if(password&&password.length<8){say("Password baru minimal 8 karakter.");return;}
    if(password!==confirmPw){say("Konfirmasi password baru tidak sama.");return;}
    try{
      const r=await api("/admin/account",{method:"POST",body:{current_password:current,username,password}});
      $("#currentAdminPassword").value="";$("#newAdminUsername").value="";$("#newAdminPassword").value="";$("#confirmAdminPassword").value="";
      setAdminIdentity(r.username);
      say("Akun admin berhasil diperbarui. Gunakan data baru saat login berikutnya.");toast("Perubahan akun admin tersimpan.");
    }catch(err){say(err.message);}
  });
  $("#logoutBtn").addEventListener("click",async()=>{try{await api("/logout",{method:"POST"});}catch{}await leaveAdmin();toast("Anda keluar dari dashboard.");});
  $("#backPublic").addEventListener("click",()=>switchView(false));
  $("#adminBrand").addEventListener("click",e=>{e.preventDefault();switchPanel("overview");});
  function switchPanel(panel){
    $$(".admin-panel").forEach(p=>p.classList.toggle("hidden",p.id!=="panel-"+panel));
    $$(".side-link").forEach(b=>b.classList.toggle("selected",b.dataset.panel===panel));
    const labels={overview:"Ringkasan",manageNews:"Berita & Pengumuman",manageComplaints:"Pengaduan Warga",manageServices:"Layanan Kelurahan",settings:"Pengaturan Portal"};
    $("#breadcrumb").textContent=labels[panel]||"Dashboard";
    if(panel==="settings")fillSettings();
    renderAdmin();
    if(panel==="manageServices")renderServiceTable();
  }
  $$(".side-link").forEach(b=>b.addEventListener("click",()=>switchPanel(b.dataset.panel)));
  $$("[data-goto]").forEach(b=>b.addEventListener("click",()=>switchPanel(b.dataset.goto)));

  // ---- Berita & pengumuman ----
  $("#quickAddNews").addEventListener("click",()=>openNewsForm());$("#addNewsBtn").addEventListener("click",()=>openNewsForm());
  function openNewsForm(n=null){
    $("#newsForm").reset();$("#editNewsId").value=n?.id||"";$("#newsModalTitle").textContent=n?"Edit Informasi":"Tambah Informasi";
    $("#newsTitleInput").value=n?.title||"";$("#newsCategoryInput").value=n?.category||"Pengumuman";$("#newsExcerptInput").value=n?.excerpt||"";$("#newsBodyInput").value=n?.body||"";$("#newsImageInput").value=n?.emoji||"";$("#newsPhotoFile").value="";$("#newsVideoFile").value="";$("#removeNewsMedia").checked=false;$("#newsPublishInput").checked=n?n.published:true;
    showModal("newsModal");
  }
  $("#newsForm").addEventListener("submit",async e=>{
    e.preventDefault();const id=$("#editNewsId").value;
    const photo=$("#newsPhotoFile").files[0],video=$("#newsVideoFile").files[0];
    if(photo&&photo.size>20*1024*1024){toast("Ukuran gambar melebihi batas 20 MB.");return;}
    if(video&&video.size>100*1024*1024){toast("Ukuran video melebihi batas 100 MB.");return;}
    if(photo&&video){toast("Pilih gambar atau video saja untuk satu berita.");return;}
    const fd=new FormData();
    fd.append("title",$("#newsTitleInput").value);fd.append("category",$("#newsCategoryInput").value);
    fd.append("excerpt",$("#newsExcerptInput").value);fd.append("body",$("#newsBodyInput").value);
    fd.append("emoji",$("#newsImageInput").value);fd.append("published",$("#newsPublishInput").checked?"1":"0");
    fd.append("remove_media",$("#removeNewsMedia").checked?"1":"0");
    if(photo)fd.append("photo",photo);if(video)fd.append("video",video);
    const btn=$("button[type=submit]",e.target),label=btn.textContent;btn.disabled=true;btn.textContent=(photo||video)?"Mengunggah…":"Menyimpan…";
    try{
      await api(id?`/admin/news/${encodeURIComponent(id)}`:"/admin/news",{method:id?"PUT":"POST",form:fd});
      hideModal("newsModal");await refreshAdmin();toast(id?"Informasi berhasil diperbarui.":"Informasi berhasil ditambahkan.");
    }catch(err){toast(err.message);}
    finally{btn.disabled=false;btn.textContent=label;}
  });
  $("#adminNewsTable").addEventListener("click",async e=>{
    const b=e.target.closest("[data-action]");if(!b)return;const n=news.find(x=>x.id===b.dataset.id);if(!n)return;
    try{
      if(b.dataset.action==="edit")openNewsForm(n);
      else if(b.dataset.action==="toggle"){await api(`/admin/news/${encodeURIComponent(n.id)}/toggle`,{method:"POST"});await refreshAdmin();toast(n.published?"Informasi dijadikan draf.":"Informasi dipublikasikan.");}
      else if(b.dataset.action==="delete"&&confirm("Hapus informasi ini? Tindakan ini tidak dapat dibatalkan.")){await api(`/admin/news/${encodeURIComponent(n.id)}`,{method:"DELETE"});await refreshAdmin();toast("Informasi dihapus.");}
    }catch(err){toast(err.message);}
  });
  $("#adminNewsSearch").addEventListener("input",renderNewsTable);$("#adminNewsStatus").addEventListener("change",renderNewsTable);
  function renderNewsTable(){
    const q=($("#adminNewsSearch").value||"").toLowerCase(),status=$("#adminNewsStatus").value;
    const rows=news.filter(n=>n.title.toLowerCase().includes(q)&&(status==="Semua"||(status==="Terbit"&&n.published)||(status==="Draf"&&!n.published))).sort((a,b)=>b.date.localeCompare(a.date));
    $("#adminNewsTable").innerHTML=rows.map(n=>`<tr><td><strong>${esc(n.title)}</strong><small>${esc(n.excerpt.slice(0,70))}${n.excerpt.length>70?"…":""}</small></td><td>${esc(n.category)}</td><td>${formatDate(n.date)}</td><td><span class="status-pill ${n.published?"published":"draft"}">${n.published?"Terbit":"Draf"}</span></td><td><div class="table-actions"><button data-action="edit" data-id="${esc(n.id)}">Edit</button><button data-action="toggle" data-id="${esc(n.id)}">${n.published?"Jadikan draf":"Terbitkan"}</button><button class="delete" data-action="delete" data-id="${esc(n.id)}">Hapus</button></div></td></tr>`).join("")||'<tr><td colspan="5">Belum ada informasi yang cocok.</td></tr>';
    $("#newsCountLabel").textContent=`Menampilkan ${rows.length} dari ${news.length} informasi`;
  }

  // ---- Pengaduan ----
  $("#adminComplaintSearch").addEventListener("input",renderComplaintTable);$("#adminComplaintStatus").addEventListener("change",renderComplaintTable);
  $("#adminComplaintTable").addEventListener("change",async e=>{
    const s=e.target.closest("[data-complaint-status]");if(!s)return;
    try{await api(`/admin/complaints/${encodeURIComponent(s.dataset.complaintStatus)}`,{method:"PATCH",body:{status:s.value}});await refreshAdmin();toast("Status pengaduan diperbarui.");}
    catch(err){toast(err.message);renderComplaintTable();}
  });
  $("#adminComplaintTable").addEventListener("click",async e=>{
    const button=e.target.closest("[data-delete-complaint]");if(!button)return;
    const ticket=button.dataset.deleteComplaint;const complaint=complaints.find(c=>c.id===ticket);if(!complaint)return;
    if(!confirm(`Hapus pengaduan ${ticket} dari ${complaint.name}? Tindakan ini tidak dapat dibatalkan.`))return;
    try{await api(`/admin/complaints/${encodeURIComponent(ticket)}`,{method:"DELETE"});await refreshAdmin();toast("Pengaduan berhasil dihapus.");}
    catch(err){toast(err.message);}
  });
  function renderComplaintTable(){
    const q=($("#adminComplaintSearch").value||"").toLowerCase(),status=$("#adminComplaintStatus").value;
    const rows=complaints.filter(c=>(c.id+" "+c.name+" "+c.category+" "+c.message).toLowerCase().includes(q)&&(status==="Semua"||c.status===status));
    $("#adminComplaintTable").innerHTML=rows.map(c=>`<tr><td><strong>${esc(c.id)} · ${esc(c.name)}</strong><small>${esc(c.message.slice(0,95))}${c.message.length>95?"…":""}<br>${esc(c.contact)}</small></td><td>${esc(c.category)}</td><td>${formatDate(c.date)}</td><td><span class="status-pill ${c.status.toLowerCase()}">${esc(c.status)}</span></td><td><select class="table-select" data-complaint-status="${esc(c.id)}"><option ${c.status==="Baru"?"selected":""}>Baru</option><option ${c.status==="Diproses"?"selected":""}>Diproses</option><option ${c.status==="Selesai"?"selected":""}>Selesai</option></select></td><td><div class="table-actions"><button type="button" class="delete" data-delete-complaint="${esc(c.id)}" aria-label="Hapus pengaduan ${esc(c.id)}">🗑 Hapus</button></div></td></tr>`).join("")||'<tr><td colspan="6">Belum ada pengaduan yang cocok.</td></tr>';
    $("#complaintCountLabel").textContent=`Menampilkan ${rows.length} dari ${complaints.length} pengaduan`;
  }
  function renderAdmin(){
    $("#statNews").textContent=news.length;$("#statPublished").textContent=news.filter(n=>n.published).length;$("#statComplaints").textContent=complaints.length;$("#statPending").textContent=complaints.filter(c=>c.status!=="Selesai").length;
    $("#complaintBadge").textContent=complaints.filter(c=>c.status==="Baru").length;
    $("#recentNews").innerHTML=[...news].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,4).map(n=>`<div class="recent-item"><div class="recent-thumb">${esc(n.emoji||"📌")}</div><div class="recent-item-main"><strong>${esc(n.title)}</strong><small>${esc(n.category)} · ${formatDate(n.date)}</small></div><span class="status-pill ${n.published?"published":"draft"}">${n.published?"Terbit":"Draf"}</span></div>`).join("")||'<p class="muted-small">Belum ada informasi.</p>';
    $("#recentComplaints").innerHTML=complaints.slice(0,4).map(c=>`<div class="recent-item"><div class="recent-thumb">✉</div><div class="recent-item-main"><strong>${esc(c.name)} · ${esc(c.category)}</strong><small>${esc(c.id)} · ${formatDate(c.date)}</small></div><span class="status-pill ${c.status.toLowerCase()}">${esc(c.status)}</span></div>`).join("")||'<p class="muted-small">Belum ada pengaduan masuk.</p>';
    renderNewsTable();renderComplaintTable();renderPublicComplaints();
  }

  // ---- Pengaturan ----
  function fillSettings(){$("#settingMusicFile").value="";$("#removeSettingMusic").checked=false;$("#musicSettingStatus").textContent=settings.musicUrl?"Musik kustom sedang digunakan.":"Musik bawaan digunakan jika tidak ada file yang diunggah.";$("#settingPhone").value=settings.phone||"";$("#settingWhatsapp").value=settings.whatsapp||"";$("#settingEmail").value=settings.email||"";$("#settingHours").value=settings.hours||"";$("#settingAddress").value=settings.address||"";$("#settingHomeTitle").value=settings.homeTitle||"";$("#settingHomeText").value=settings.homeText||"";}
  $("#settingsForm").addEventListener("submit",async e=>{
    e.preventDefault();
    const musicFile=$("#settingMusicFile").files[0];
    if(musicFile&&musicFile.size>15*1024*1024){toast("Ukuran musik melebihi batas 15 MB.");return;}
    if(musicFile&&!musicFile.type.startsWith("audio/")){toast("File harus berupa audio.");return;}
    const fd=new FormData();
    fd.append("phone",$("#settingPhone").value);fd.append("whatsapp",$("#settingWhatsapp").value);fd.append("email",$("#settingEmail").value);
    fd.append("hours",$("#settingHours").value);fd.append("address",$("#settingAddress").value);
    fd.append("homeTitle",$("#settingHomeTitle").value);fd.append("homeText",$("#settingHomeText").value);
    fd.append("remove_music",$("#removeSettingMusic").checked?"1":"0");if(musicFile)fd.append("music",musicFile);
    const btn=$("button[type=submit]",e.target);btn.disabled=true;
    try{settings=await api("/admin/settings",{method:"PUT",form:fd});fillSettings();renderPublicAll();toast("Pengaturan portal berhasil disimpan.");}
    catch(err){toast(err.message);}
    finally{btn.disabled=false;}
  });
  function applyHomeText(){const h=$(".hero h1"),p=$(".hero-copy > p");if(settings.homeTitle&&h){const words=settings.homeTitle.split(" ");h.textContent="";if(words.length>2){h.append(document.createTextNode(words.slice(0,-2).join(" ")+" "));const span=document.createElement("span");span.textContent=words.slice(-2).join(" ");h.append(span);}else h.textContent=settings.homeTitle;}if(settings.homeText&&p)p.textContent=settings.homeText;}
  function renderContact(){
    const phone=settings.phone;const call=$("#callLink");
    if(phone){call.textContent=phone+" · Hubungi";call.href="tel:"+phone.replace(/[^\d+]/g,"");call.hidden=false;}else{call.hidden=true;}
    const cards=$$(".contact-card");
    if(cards[1]&&settings.address)cards[1].querySelector("p").textContent=settings.address;
    if(cards[2]&&settings.hours)cards[2].querySelector("p").textContent=settings.hours;
    if(cards[0]){const p=cards[0].querySelector("p");p.textContent=phone?"Telepon: "+phone:"Hubungi kantor kelurahan pada jam pelayanan.";cards[0].querySelectorAll(".contact-extra").forEach(x=>x.remove());const box=cards[0].querySelector("div");
      if(settings.whatsapp){const a=document.createElement("a");a.className="text-link contact-extra";a.target="_blank";a.rel="noopener";a.href="https://wa.me/"+settings.whatsapp.replace(/\D/g,"");a.textContent="Hubungi via WhatsApp ↗";box.appendChild(a);}
      if(settings.email){const a=document.createElement("a");a.className="text-link contact-extra";a.href="mailto:"+settings.email;a.textContent=settings.email;box.appendChild(a);}}
  }

  // ---- Layanan ----
  function renderServiceTable(){
    $("#adminServiceTable").innerHTML=services.map(x=>`<tr><td><strong>${esc(x.name)}</strong></td><td>${esc(x.summary)}</td><td><div class="table-actions"><button data-service-action="edit" data-id="${esc(x.id)}">Edit</button><button class="delete" data-service-action="delete" data-id="${esc(x.id)}">Hapus</button></div></td></tr>`).join("")||'<tr><td colspan="3">Belum ada layanan.</td></tr>';
    $("#serviceCountLabel").textContent=`${services.length} layanan tersedia`;
  }
  function openServiceForm(item=null){$("#serviceForm").reset();$("#editServiceId").value=item?.id||"";$("#serviceModalTitle").textContent=item?"Edit Layanan":"Tambah Layanan";$("#serviceNameInput").value=item?.name||"";$("#serviceSummaryInput").value=item?.summary||"";$("#serviceBodyInput").value=item?.body||"";showModal("serviceModal");}
  $("#addServiceBtn").addEventListener("click",()=>openServiceForm());
  $("#serviceForm").addEventListener("submit",async e=>{
    e.preventDefault();const id=$("#editServiceId").value;
    const body={name:$("#serviceNameInput").value,summary:$("#serviceSummaryInput").value,body:$("#serviceBodyInput").value};
    const btn=$("button[type=submit]",e.target);btn.disabled=true;
    try{await api(id?`/admin/services/${encodeURIComponent(id)}`:"/admin/services",{method:id?"PUT":"POST",body});hideModal("serviceModal");await refreshAdmin();renderServiceTable();toast(id?"Layanan berhasil diperbarui.":"Layanan berhasil ditambahkan.");}
    catch(err){toast(err.message);}
    finally{btn.disabled=false;}
  });
  $("#adminServiceTable").addEventListener("click",async e=>{
    const b=e.target.closest("[data-service-action]");if(!b)return;const item=services.find(x=>x.id===b.dataset.id);if(!item)return;
    if(b.dataset.serviceAction==="edit"){openServiceForm(item);return;}
    if(!confirm(`Hapus layanan ${item.name}?`))return;
    try{await api(`/admin/services/${encodeURIComponent(item.id)}`,{method:"DELETE"});await refreshAdmin();renderServiceTable();toast("Layanan berhasil dihapus.");}
    catch(err){toast(err.message);}
  });

  // ---- Mulai ----
  (async()=>{
    try{await loadPublic();}catch(err){toast(err.message);}
    renderPublicAll();
    try{const me=await api("/me");if(me.authenticated){csrf=me.csrf;setAdminIdentity(me.username);}}catch{}
  })();
})();
